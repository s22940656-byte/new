# VcamDroid — Virtual Camera Engine for Android

> Inject any local MP4 video as a virtual camera feed on Android 13+.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        VcamDroid Architecture                                │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                       Jetpack Compose UI                              │   │
│  │  ┌────────────┐  ┌─────────────────┐  ┌──────────┐  ┌───────────┐  │   │
│  │  │Video Picker│  │ Master Toggle   │  │Settings  │  │Injection  │  │   │
│  │  │(SAF/Media) │  │ (On/Off Switch) │  │(Loop,Mir)│  │Method Sel.│  │   │
│  │  └────────────┘  └─────────────────┘  └──────────┘  └───────────┘  │   │
│  └──────────────────────────────┬───────────────────────────────────────┘   │
│                                 │ StateFlow (MainViewModel)                  │
│  ┌──────────────────────────────▼───────────────────────────────────────┐   │
│  │                     MainViewModel (AndroidViewModel)                   │   │
│  │  • DataStore (prefs)     • ServiceStatus bridging                     │   │
│  │  • VideoMetadataUtil     • Permission state                           │   │
│  └──────────────────────────────┬───────────────────────────────────────┘   │
│                                 │ startForegroundService(Intent)             │
│  ┌──────────────────────────────▼───────────────────────────────────────┐   │
│  │              VirtualCameraService (ForegroundService)                  │   │
│  │                                                                        │   │
│  │   MediaPlayer ──► SurfaceTexture ──► onFrameAvailable()               │   │
│  │                           │                    │                       │   │
│  │                           └────────────────────▼                      │   │
│  │                                         FrameRouter (interface)        │   │
│  │                                              │                         │   │
│  │              ┌───────────────────────────────┼───────────────────┐    │   │
│  │              ▼                               ▼                   ▼    │   │
│  │   SurfaceTextureFrameRouter   VirtualDisplayFrameRouter   (Xposed)    │   │
│  └────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                    CameraInjector (modular layer)                      │   │
│  │                                                                        │   │
│  │  InAppPreviewInjector ──► EglFramePipeline (GPU blit via EGL/GLES2)   │   │
│  │  Camera2CompatInjector ──► CameraDevice / CaptureSession (root)       │   │
│  │  XposedInjector ──► Hook Camera2.openCamera() (LSPosed module)        │   │
│  └────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## File Structure

```
VcamDroid/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/vcamdroid/
│           ├── VcamApp.kt                    # Application class, notification channels
│           ├── MainActivity.kt               # Compose entry point
│           │
│           ├── ui/
│           │   ├── MainViewModel.kt          # Central state (StateFlow)
│           │   ├── theme/
│           │   │   ├── Theme.kt              # Dark techy color palette
│           │   │   └── Typography.kt         # Mono + Sans font pairing
│           │   ├── screens/
│           │   │   └── MainScreen.kt         # Root Compose screen
│           │   └── components/
│           │       ├── AppHeader.kt          # Header + animated grid bg
│           │       ├── StatusBanner.kt       # Live status indicator
│           │       ├── VideoPreviewCard.kt   # File picker + thumbnail
│           │       ├── MasterToggleCard.kt   # Power toggle button
│           │       └── Cards.kt             # Settings, Info, Error, Permissions
│           │
│           ├── service/
│           │   ├── VirtualCameraService.kt   # Foreground service + FrameRouter impls
│           │   └── ServiceControlReceiver.kt # Notification "Stop" button handler
│           │
│           ├── camera/
│           │   ├── CameraInjector.kt         # Injection interface + all strategies
│           │   └── EglFramePipeline.kt       # OpenGL ES 2.0 GPU frame blit pipeline
│           │
│           └── util/
│               ├── Models.kt                 # Data classes, enums, state
│               └── VideoMetadataUtil.kt      # ContentResolver + MediaMetadata helpers
│
├── build.gradle
└── settings.gradle
```

---

## Injection Methods Explained

| Method | Root? | LSPosed? | Scope | Description |
|---|---|---|---|---|
| **SurfaceTexture** | ❌ | ❌ | In-app | Default. Routes frames to the app's own preview surface. |
| **Virtual Display** | ❌ | ❌ | Screen share | Uses `MediaProjection` + `VirtualDisplay`. Works for apps that accept a screen share stream (e.g. Google Meet screen share). |
| **Camera2 Stub** | ✅ | ❌ | Device-wide | Opens a Camera2 device and replaces capture output. Requires `CAMERA` + system permissions or root via Magisk. |
| **Xposed / LSPosed** | ✅ | ✅ | Process-wide | Hooks `CameraManager.openCamera()` in the target app's process. Transparent to the target app — it sees a real camera. |

---

## Permissions Required

| Permission | Reason |
|---|---|
| `READ_MEDIA_VIDEO` | Read MP4 files from device storage (Android 13+ scoped storage) |
| `FOREGROUND_SERVICE` | Run the virtual camera service in the background |
| `FOREGROUND_SERVICE_CAMERA` | Declare the service uses the camera foreground type |
| `FOREGROUND_SERVICE_MEDIA_PLAYBACK` | Declare the service does media playback |
| `POST_NOTIFICATIONS` | Show the persistent service notification (Android 13+) |
| `WAKE_LOCK` | Keep CPU awake during long video playback |
| `CAMERA` | Required for Camera2Compat injection mode |

---

## Build & Run

### Prerequisites
- Android Studio Hedgehog (2023.1.1) or newer
- JDK 17
- Android SDK 34

### Steps
```bash
git clone <repo>
cd VcamDroid
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

### For Xposed / LSPosed mode
1. Install LSPosed from https://github.com/LSPosed/LSPosed/releases
2. Enable VcamDroid as an Xposed module in LSPosed Manager
3. Select which target app to hook
4. Reboot (or soft-reboot via LSPosed)

---

## Key Dependencies

| Library | Version | Purpose |
|---|---|---|
| Jetpack Compose BOM | 2024.01.00 | Modern declarative UI |
| Material3 | via Compose BOM | Design system |
| Media3 ExoPlayer | 1.2.1 | Video decode & preview |
| Accompanist Permissions | 0.32.0 | Compose permission handling |
| DataStore Preferences | 1.0.0 | Persistent settings |
| Coil (+ Video) | 2.5.0 | Video thumbnail loading |
| Lifecycle ViewModel | 2.7.0 | MVVM state management |

---

## Extending with New Injection Strategies

Implement the `FrameRouter` interface (in-service, simple) **or** the `CameraInjector`
interface (standalone, with EGL pipeline support):

```kotlin
class MyCustomRouter : FrameRouter {
    override fun initialize() { /* set up your sink */ }
    override fun onFrameAvailable(surfaceTexture: SurfaceTexture) { /* forward frame */ }
    override fun release() { /* clean up */ }
}
```

Then swap it in `VirtualCameraService.initializePipeline()`:
```kotlin
frameRouter = MyCustomRouter().also { it.initialize() }
```

---

## Legal & Ethical Note

Using a virtual camera to impersonate another person or to deceive others in a way
that causes harm may violate laws in your jurisdiction and the Terms of Service of
apps you use. VcamDroid is provided for legitimate use cases such as privacy protection,
testing, content creation, and accessibility.
