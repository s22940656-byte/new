# VcamDroid ProGuard Rules

# Keep all public API classes
-keep class com.vcamdroid.camera.** { *; }
-keep class com.vcamdroid.service.** { *; }
-keep class com.vcamdroid.util.** { *; }

# Keep Xposed hook entry point (when used as module)
-keep class com.vcamdroid.camera.XposedInitHook { *; }

# Media3 / ExoPlayer
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# Coil
-dontwarn coil.**

# Kotlin serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
