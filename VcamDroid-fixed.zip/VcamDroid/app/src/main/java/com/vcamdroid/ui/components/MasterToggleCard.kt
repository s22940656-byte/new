package com.vcamdroid.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vcamdroid.ui.theme.*
import com.vcamdroid.util.MainUiState
import com.vcamdroid.util.ServiceStatus

@Composable
fun MasterToggleCard(
    uiState: MainUiState,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isActive = uiState.isServiceRunning
    val canToggle = uiState.canStartService || isActive
    val isStarting = uiState.serviceStatus == ServiceStatus.STARTING
    val isStopping = uiState.serviceStatus == ServiceStatus.STOPPING

    val accentColor by animateColorAsState(
        targetValue = when {
            isActive   -> ActiveGreen
            canToggle  -> NeonCyan
            else       -> TextTertiary
        },
        animationSpec = tween(400),
        label = "accentColor"
    )

    // Pulse animation when active
    val infiniteTransition = rememberInfiniteTransition(label = "activePulse")
    val buttonScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isActive) 1.02f else 1f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "btnScale"
    )

    VcamCard(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.Power,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = "VIRTUAL CAMERA",
                    style = MaterialTheme.typography.labelSmall,
                    color = accentColor
                )
            }

            // Toggle button
            Button(
                onClick = onToggle,
                enabled = canToggle && !isStarting && !isStopping,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .scale(buttonScale),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) ActiveGreen else NeonCyan,
                    contentColor = DeepNavy,
                    disabledContainerColor = ElevatedNavy,
                    disabledContentColor = TextTertiary
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isStarting || isStopping) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = NeonCyan,
                        strokeWidth = 2.dp
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (isStarting) "Starting…" else "Stopping…",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = if (isActive) Icons.Rounded.VideocamOff else Icons.Rounded.Videocam,
                        contentDescription = null,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = if (isActive) "Turn Off Virtual Camera"
                               else if (canToggle) "Turn On Virtual Camera"
                               else "Select a Video First",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Hint text
            if (!canToggle && !isActive) {
                Text(
                    text = "↑ Pick an MP4 file above to enable the camera feed",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextTertiary,
                    modifier = Modifier.fillMaxWidth()
                )
            } else if (isActive) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Rounded.Info,
                        null,
                        Modifier.size(12.dp),
                        tint = TextSecondary
                    )
                    Text(
                        text = "Running in background. Pull down notification to stop.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}
