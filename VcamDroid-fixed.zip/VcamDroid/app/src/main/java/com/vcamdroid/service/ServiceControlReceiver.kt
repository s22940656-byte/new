package com.vcamdroid.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vcamdroid.util.Constants

/**
 * Handles notification action intents (e.g. the "Stop" button in the
 * persistent foreground notification).
 */
class ServiceControlReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            "com.vcamdroid.ACTION_STOP_SERVICE" -> {
                val stopIntent = Intent(context, VirtualCameraService::class.java).apply {
                    action = Constants.SERVICE_ACTION_STOP
                }
                context.stopService(stopIntent)
            }
            "com.vcamdroid.ACTION_TOGGLE_SERVICE" -> {
                // Placeholder for future toggle support
            }
        }
    }
}
