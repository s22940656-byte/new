package com.vcamdroid.camera

import android.graphics.SurfaceTexture
import android.opengl.*
import android.util.Log
import android.view.Surface

/**
 * EglFramePipeline
 *
 * A minimal EGL + OpenGL ES 2.0 pipeline that:
 *   1. Creates an EGL context.
 *   2. Attaches a [SurfaceTexture] (the video output from MediaPlayer) as an
 *      external OES texture.
 *   3. Blits each decoded frame to one or more output [Surface]s.
 *
 * This is the building block for GPU-side frame routing without copying pixel
 * data through the CPU (which would be far too slow for real-time video).
 *
 * Usage:
 * ```
 *   val pipeline = EglFramePipeline()
 *   pipeline.initialize(outputSurface, width, height)
 *   // ...in frame available callback:
 *   pipeline.drawFrame(srcTexture, transformMatrix)
 *   pipeline.release()
 * ```
 */
class EglFramePipeline {

    companion object {
        private const val TAG = "EglFramePipeline"
        private const val EGL_RECORDABLE_ANDROID = 0x3142
    }

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var programHandle: Int = 0
    private var textureHandle: Int = 0

    // Vertex shader — full-screen quad
    private val VERTEX_SHADER = """
        attribute vec4 aPosition;
        attribute vec4 aTexCoord;
        varying vec2 vTexCoord;
        uniform mat4 uTexMatrix;
        void main() {
            gl_Position = aPosition;
            vTexCoord = (uTexMatrix * aTexCoord).xy;
        }
    """.trimIndent()

    // Fragment shader — samples from the OES external texture
    private val FRAGMENT_SHADER = """
        #extension GL_OES_EGL_image_external : require
        precision mediump float;
        varying vec2 vTexCoord;
        uniform samplerExternalOES uTexture;
        void main() {
            gl_FragColor = texture2D(uTexture, vTexCoord);
        }
    """.trimIndent()

    /**
     * Initialize EGL context and compile shaders.
     * Must be called from the rendering thread.
     */
    fun initialize(outputSurface: Surface, width: Int, height: Int): Boolean {
        return try {
            setupEgl(outputSurface)
            programHandle = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            true
        } catch (e: Exception) {
            Log.e(TAG, "EGL initialization failed", e)
            false
        }
    }

    /**
     * Draw the latest frame from [srcTexture] to the current EGL surface.
     * @param transformMatrix The SurfaceTexture.getTransformMatrix() result
     */
    fun drawFrame(srcTexture: SurfaceTexture, transformMatrix: FloatArray) {
        srcTexture.updateTexImage()

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        GLES20.glUseProgram(programHandle)

        // Bind texture
        val texLoc = GLES20.glGetUniformLocation(programHandle, "uTexture")
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureHandle)
        GLES20.glUniform1i(texLoc, 0)

        // Set transform matrix
        val matLoc = GLES20.glGetUniformLocation(programHandle, "uTexMatrix")
        GLES20.glUniformMatrix4fv(matLoc, 1, false, transformMatrix, 0)

        // Draw full-screen quad
        drawFullScreenQuad()

        EGL14.eglSwapBuffers(eglDisplay, eglSurface)
    }

    /** Release all EGL resources. */
    fun release() {
        EGL14.eglMakeCurrent(
            eglDisplay,
            EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE,
            EGL14.EGL_NO_CONTEXT
        )
        EGL14.eglDestroySurface(eglDisplay, eglSurface)
        EGL14.eglDestroyContext(eglDisplay, eglContext)
        EGL14.eglTerminate(eglDisplay)
        eglDisplay = EGL14.EGL_NO_DISPLAY
        eglContext = EGL14.EGL_NO_CONTEXT
        eglSurface = EGL14.EGL_NO_SURFACE
    }

    // ── Private helpers ────────────────────────────────────────────────────────

    private fun setupEgl(surface: Surface) {
        eglDisplay = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val version = IntArray(2)
        EGL14.eglInitialize(eglDisplay, version, 0, version, 1)

        val attribList = intArrayOf(
            EGL14.EGL_RED_SIZE, 8,
            EGL14.EGL_GREEN_SIZE, 8,
            EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL_RECORDABLE_ANDROID, 1,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val numConfigs = IntArray(1)
        EGL14.eglChooseConfig(eglDisplay, attribList, 0, configs, 0, 1, numConfigs, 0)

        val ctxAttribs = intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        eglContext = EGL14.eglCreateContext(eglDisplay, configs[0], EGL14.EGL_NO_CONTEXT, ctxAttribs, 0)

        val surfAttribs = intArrayOf(EGL14.EGL_NONE)
        eglSurface = EGL14.eglCreateWindowSurface(eglDisplay, configs[0], surface, surfAttribs, 0)

        EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)

        // Generate OES texture
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        textureHandle = textures[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, textureHandle)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
    }

    private fun buildProgram(vertSrc: String, fragSrc: String): Int {
        val vert = compileShader(GLES20.GL_VERTEX_SHADER, vertSrc)
        val frag = compileShader(GLES20.GL_FRAGMENT_SHADER, fragSrc)
        return GLES20.glCreateProgram().also { prog ->
            GLES20.glAttachShader(prog, vert)
            GLES20.glAttachShader(prog, frag)
            GLES20.glLinkProgram(prog)
        }
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        return shader
    }

    private fun drawFullScreenQuad() {
        val vertices = floatArrayOf(
            -1f, -1f,  0f, 0f,
             1f, -1f,  1f, 0f,
            -1f,  1f,  0f, 1f,
             1f,  1f,  1f, 1f
        )
        val buf = java.nio.ByteBuffer
            .allocateDirect(vertices.size * 4)
            .order(java.nio.ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply { put(vertices); flip() }

        val posLoc = GLES20.glGetAttribLocation(programHandle, "aPosition")
        val texLoc = GLES20.glGetAttribLocation(programHandle, "aTexCoord")

        buf.position(0)
        GLES20.glEnableVertexAttribArray(posLoc)
        GLES20.glVertexAttribPointer(posLoc, 2, GLES20.GL_FLOAT, false, 16, buf)

        buf.position(2)
        GLES20.glEnableVertexAttribArray(texLoc)
        GLES20.glVertexAttribPointer(texLoc, 2, GLES20.GL_FLOAT, false, 16, buf)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(posLoc)
        GLES20.glDisableVertexAttribArray(texLoc)
    }
}
