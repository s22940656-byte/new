package com.vcamdroid.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.vcamdroid.service.VirtualCameraService
import com.vcamdroid.util.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

private val android.content.Context.dataStore: DataStore<Preferences>
    by preferencesDataStore(name = "vcam_prefs")

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val context get() = getApplication<Application>()

    // ── Preferences Keys ──────────────────────────────────────────────────────
    private val KEY_LAST_URI    = stringPreferencesKey(Constants.PREF_LAST_VIDEO_URI)
    private val KEY_LOOP        = booleanPreferencesKey(Constants.PREF_LOOP_ENABLED)
    private val KEY_MIRROR      = booleanPreferencesKey(Constants.PREF_MIRROR_ENABLED)

    // ── Internal State ────────────────────────────────────────────────────────
    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    // ServiceStatus bridge: the service updates this via broadcast/binder
    private val _serviceStatus = MutableStateFlow(ServiceStatus.IDLE)

    init {
        // Combine service status into UI state
        viewModelScope.launch {
            _serviceStatus.collect { status ->
                _uiState.update { it.copy(serviceStatus = status) }
            }
        }

        // Restore preferences
        viewModelScope.launch {
            context.dataStore.data.first().let { prefs ->
                val loopEnabled   = prefs[KEY_LOOP]   ?: true
                val mirrorEnabled = prefs[KEY_MIRROR] ?: false
                val lastUriStr    = prefs[KEY_LAST_URI]

                _uiState.update {
                    it.copy(
                        isLoopEnabled   = loopEnabled,
                        isMirrorEnabled = mirrorEnabled
                    )
                }

                // Try to re-load last video (URI persistence)
                lastUriStr?.let { uriStr ->
                    try {
                        val uri = Uri.parse(uriStr)
                        // Check if still accessible
                        context.contentResolver.openInputStream(uri)?.close()
                        loadVideoFromUri(uri)
                    } catch (_: Exception) {
                        // URI no longer valid; clear it
                        clearSavedUri()
                    }
                }
            }
        }
    }

    // ── Permission Handling ───────────────────────────────────────────────────

    fun onPermissionsGranted() {
        _uiState.update { it.copy(permissionsGranted = true, showPermissionRationale = false) }
    }

    fun onPermissionsDenied() {
        _uiState.update { it.copy(permissionsGranted = false, showPermissionRationale = true) }
    }

    fun dismissPermissionRationale() {
        _uiState.update { it.copy(showPermissionRationale = false) }
    }

    // ── Video Selection ───────────────────────────────────────────────────────

    fun onVideoSelected(uri: Uri) {
        viewModelScope.launch {
            val videoInfo = VideoMetadataUtil.getVideoInfo(context, uri)
            if (videoInfo != null) {
                _uiState.update { state ->
                    state.copy(
                        selectedVideo = videoInfo,
                        serviceStatus = if (state.serviceStatus == ServiceStatus.IDLE)
                            ServiceStatus.READY else state.serviceStatus,
                        errorMessage = null
                    )
                }
                saveUri(uri)
            } else {
                _uiState.update {
                    it.copy(errorMessage = "Could not read video metadata. Is this a valid MP4?")
                }
            }
        }
    }

    fun clearSelectedVideo() {
        // Stop service first if running
        if (_uiState.value.isServiceRunning) stopService()

        _uiState.update {
            it.copy(
                selectedVideo = null,
                serviceStatus = ServiceStatus.IDLE,
                errorMessage = null
            )
        }
        clearSavedUri()
    }

    // ── Service Control ───────────────────────────────────────────────────────

    fun toggleService() {
        val state = _uiState.value
        if (state.isServiceRunning) {
            stopService()
        } else if (state.canStartService) {
            startService()
        }
    }

    private fun startService() {
        val state = _uiState.value
        val video = state.selectedVideo ?: return

        _uiState.update { it.copy(serviceStatus = ServiceStatus.STARTING, errorMessage = null) }

        val intent = Intent(context, VirtualCameraService::class.java).apply {
            action = Constants.SERVICE_ACTION_START
            putExtra(Constants.EXTRA_VIDEO_URI, video.uri.toString())
            putExtra(Constants.EXTRA_LOOP_ENABLED, state.isLoopEnabled)
            putExtra(Constants.EXTRA_MIRROR_ENABLED, state.isMirrorEnabled)
        }

        try {
            context.startForegroundService(intent)
            // Optimistically update state; service will confirm via broadcast
            _uiState.update { it.copy(serviceStatus = ServiceStatus.ACTIVE) }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    serviceStatus = ServiceStatus.ERROR,
                    errorMessage = "Failed to start service: ${e.message}"
                )
            }
        }
    }

    fun stopService() {
        _uiState.update { it.copy(serviceStatus = ServiceStatus.STOPPING) }

        val intent = Intent(context, VirtualCameraService::class.java).apply {
            action = Constants.SERVICE_ACTION_STOP
        }
        context.stopService(intent)

        _uiState.update {
            it.copy(
                serviceStatus = if (it.selectedVideo != null)
                    ServiceStatus.READY else ServiceStatus.IDLE
            )
        }
    }

    // ── Settings ──────────────────────────────────────────────────────────────

    fun setLoopEnabled(enabled: Boolean) {
        _uiState.update { it.copy(isLoopEnabled = enabled) }
        viewModelScope.launch {
            context.dataStore.edit { prefs -> prefs[KEY_LOOP] = enabled }
        }
        if (_uiState.value.isServiceRunning) sendSettingsUpdate()
    }

    fun setMirrorEnabled(enabled: Boolean) {
        _uiState.update { it.copy(isMirrorEnabled = enabled) }
        viewModelScope.launch {
            context.dataStore.edit { prefs -> prefs[KEY_MIRROR] = enabled }
        }
        if (_uiState.value.isServiceRunning) sendSettingsUpdate()
    }

    fun setInjectionMethod(method: InjectionMethod) {
        _uiState.update { it.copy(injectionMethod = method) }
    }

    fun dismissError() {
        _uiState.update { it.copy(errorMessage = null) }
    }

    // ── Private Helpers ───────────────────────────────────────────────────────

    private fun sendSettingsUpdate() {
        val state = _uiState.value
        val intent = Intent(context, VirtualCameraService::class.java).apply {
            action = Constants.SERVICE_ACTION_UPDATE
            putExtra(Constants.EXTRA_LOOP_ENABLED, state.isLoopEnabled)
            putExtra(Constants.EXTRA_MIRROR_ENABLED, state.isMirrorEnabled)
        }
        context.startService(intent)
    }

    private fun saveUri(uri: Uri) {
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs[KEY_LAST_URI] = uri.toString()
            }
        }
    }

    private fun clearSavedUri() {
        viewModelScope.launch {
            context.dataStore.edit { prefs ->
                prefs.remove(KEY_LAST_URI)
            }
        }
    }

    private fun loadVideoFromUri(uri: Uri) {
        val videoInfo = VideoMetadataUtil.getVideoInfo(context, uri)
        if (videoInfo != null) {
            _uiState.update {
                it.copy(
                    selectedVideo = videoInfo,
                    serviceStatus = ServiceStatus.READY
                )
            }
        }
    }

    // Called from service via broadcast (future improvement: use binder)
    fun onServiceStatusChanged(status: ServiceStatus) {
        _serviceStatus.value = status
    }
}
