package com.vcamdroid.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.vcamdroid.ui.theme.*
import com.vcamdroid.util.ServiceStatus

@Composable
fun StatusBanner(
    status: ServiceStatus,
    modifier: Modifier = Modifier
) {
    val (label, dotColor, bgTint) = when (status) {
        ServiceStatus.IDLE     -> Triple("IDLE — No video loaded",       TextTertiary,  Color.Transparent)
        ServiceStatus.READY    -> Triple("READY — Select video & start", NeonCyanDim,   NeonCyan.copy(alpha = 0.05f))
        ServiceStatus.STARTING -> Triple("STARTING…",                   Color(0xFFFFAA00), Color(0xFFFFAA00).copy(0.07f))
        ServiceStatus.ACTIVE   -> Triple("ACTIVE — Virtual camera ON",  ActiveGreen,   ActiveGreen.copy(alpha = 0.07f))
        ServiceStatus.STOPPING -> Triple("STOPPING…",                   TextSecondary, Color.Transparent)
        ServiceStatus.ERROR    -> Triple("ERROR — Check video file",     ErrorRed,      ErrorRed.copy(alpha = 0.07f))
    }

    val animatedBg by animateColorAsState(bgTint, animationSpec = tween(400), label = "bgAnim")
    val animatedDot by animateColorAsState(dotColor, animationSpec = tween(400), label = "dotAnim")

    // Pulsing animation for active/starting states
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (status == ServiceStatus.ACTIVE || status == ServiceStatus.STARTING) 1.4f else 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseScale"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(animatedBg)
            .border(1.dp, BorderBlue, RoundedCornerShape(10.dp))
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Status dot
        Box(contentAlignment = Alignment.Center) {
            // Outer glow ring
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(animatedDot.copy(alpha = 0.3f))
            )
            // Inner dot
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(animatedDot)
            )
        }

        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = if (status == ServiceStatus.IDLE) TextTertiary else TextPrimary
        )
    }
}
