package com.vcamdroid.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── Palette ─────────────────────────────────────────────────────────────────
val NeonCyan       = Color(0xFF00E5FF)
val NeonCyanDim    = Color(0xFF00B8CC)
val DeepNavy       = Color(0xFF060C14)
val SurfaceNavy    = Color(0xFF0D1520)
val CardNavy       = Color(0xFF111D2E)
val ElevatedNavy   = Color(0xFF172438)
val BorderBlue     = Color(0xFF1E3050)
val ActiveGreen    = Color(0xFF00FF88)
val ErrorRed       = Color(0xFFFF3B5C)
val TextPrimary    = Color(0xFFE8F0FE)
val TextSecondary  = Color(0xFF7A9CC0)
val TextTertiary   = Color(0xFF3D5A7A)

private val DarkColorScheme = darkColorScheme(
    primary          = NeonCyan,
    onPrimary        = DeepNavy,
    primaryContainer = ElevatedNavy,
    onPrimaryContainer = NeonCyan,
    secondary        = NeonCyanDim,
    onSecondary      = DeepNavy,
    secondaryContainer = CardNavy,
    onSecondaryContainer = TextPrimary,
    tertiary         = ActiveGreen,
    onTertiary       = DeepNavy,
    background       = DeepNavy,
    onBackground     = TextPrimary,
    surface          = SurfaceNavy,
    onSurface        = TextPrimary,
    surfaceVariant   = CardNavy,
    onSurfaceVariant = TextSecondary,
    outline          = BorderBlue,
    error            = ErrorRed,
    onError          = Color.White,
)

@Composable
fun VcamDroidTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = VcamTypography,
        content = content
    )
}
