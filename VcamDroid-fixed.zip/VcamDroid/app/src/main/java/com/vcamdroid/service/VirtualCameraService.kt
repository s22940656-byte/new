package com.vcamdroid.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.vcamdroid.MainActivity
import com.vcamdroid.R
import com.vcamdroid.VcamApp
import com.vcamdroid.util.Constants

/**
 * VirtualCameraService — Foreground Service
 *
 * Architecture:
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  MediaPlayer  ──► SurfaceTexture (offscreen) ──► FrameRouter    │
 * │                                                      │           │
 * │              ┌───────────────────────────────────────┘           │
 * │              ▼                                                   │
 * │  ┌─────────────────────┐    ┌──────────────────────────────┐    │
 * │  │  VirtualDisplay     │    │  Camera2 Stub / Xposed Hook  │    │
 * │  │  (screen capture    │    │  (system-wide injection –     │    │
 * │  │   path)             │    │   requires root/LSPosed)      │    │
 * │  └─────────────────────┘    └──────────────────────────────┘    │
 * └──────────────────────────────────────────────────────────────────┘
 *
 * Default mode uses SurfaceTexture routing for in-app preview.
 * The modular [FrameRouter] interface allows swapping injection strategies.
 */
class VirtualCameraService : LifecycleService() {

    companion object {
        private const val TAG = "VirtualCameraService"
        private const val WAKE_LOCK_TAG = "VcamDroid:VirtualCameraWakeLock"

        // Width/height of the internal offscreen buffer
        private const val BUFFER_WIDTH  = 1280
        private const val BUFFER_HEIGHT = 720
    }

    // ── State ──────────────────────────────────────────────────────────────────

    private var mediaPlayer: MediaPlayer? = null
    private var surfaceTexture: SurfaceTexture? = null
    private var surface: Surface? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var frameRouter: FrameRouter? = null

    private var videoUri: Uri? = null
    private var loopEnabled: Boolean = true
    private var mirrorEnabled: Boolean = false
    private var isStarted: Boolean = false

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        acquireWakeLock()
        Log.i(TAG, "Service created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        when (intent?.action) {
            Constants.SERVICE_ACTION_START  -> handleStart(intent)
            Constants.SERVICE_ACTION_STOP   -> handleStop()
            Constants.SERVICE_ACTION_UPDATE -> handleUpdate(intent)
            else                            -> startForegroundWithNotification()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null // Not a bound service; use intents
    }

    override fun onDestroy() {
        releaseResources()
        releaseWakeLock()
        super.onDestroy()
        Log.i(TAG, "Service destroyed")
    }

    // ── Command Handlers ───────────────────────────────────────────────────────

    private fun handleStart(intent: Intent) {
        val uriString = intent.getStringExtra(Constants.EXTRA_VIDEO_URI) ?: run {
            Log.e(TAG, "No video URI provided")
            stopSelf()
            return
        }

        videoUri      = Uri.parse(uriString)
        loopEnabled   = intent.getBooleanExtra(Constants.EXTRA_LOOP_ENABLED, true)
        mirrorEnabled = intent.getBooleanExtra(Constants.EXTRA_MIRROR_ENABLED, false)

        startForegroundWithNotification()
        initializePipeline()
    }

    private fun handleStop() {
        releaseResources()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun handleUpdate(intent: Intent) {
        loopEnabled   = intent.getBooleanExtra(Constants.EXTRA_LOOP_ENABLED, loopEnabled)
        mirrorEnabled = intent.getBooleanExtra(Constants.EXTRA_MIRROR_ENABLED, mirrorEnabled)
        mediaPlayer?.isLooping = loopEnabled
        Log.d(TAG, "Settings updated: loop=$loopEnabled, mirror=$mirrorEnabled")
    }

    // ── Media Pipeline ─────────────────────────────────────────────────────────

    /**
     * Sets up the offscreen MediaPlayer → SurfaceTexture → FrameRouter pipeline.
     *
     *  SurfaceTexture provides an OpenGL ES texture that the MediaPlayer renders
     *  video frames into. We then pass those frames downstream to whichever
     *  [FrameRouter] implementation is active.
     */
    private fun initializePipeline() {
        try {
            releaseResources(keepWakeLock = true)

            // 1. Create an offscreen SurfaceTexture (texName=0 is a placeholder;
            //    a real GL context would use glGenTextures)
            surfaceTexture = SurfaceTexture(0).apply {
                setDefaultBufferSize(BUFFER_WIDTH, BUFFER_HEIGHT)
                setOnFrameAvailableListener { st ->
                    // Each time MediaPlayer writes a new frame, notify the router
                    frameRouter?.onFrameAvailable(st)
                }
            }

            // 2. Wrap in a Surface for MediaPlayer
            surface = Surface(surfaceTexture)

            // 3. Initialize the FrameRouter (default: SurfaceTexture-only)
            frameRouter = SurfaceTextureFrameRouter(BUFFER_WIDTH, BUFFER_HEIGHT).also {
                it.initialize()
            }

            // 4. Set up MediaPlayer
            mediaPlayer = MediaPlayer().apply {
                setDataSource(applicationContext, videoUri!!)
                setSurface(surface)
                isLooping = loopEnabled
                setVideoScalingMode(MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING)

                setOnPreparedListener { mp ->
                    mp.start()
                    isStarted = true
                    updateNotification(playing = true)
                    Log.i(TAG, "MediaPlayer started: ${videoUri}")
                }

                setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error: what=$what extra=$extra")
                    updateNotification(playing = false, error = true)
                    false // false = not handled → triggers onCompletionListener
                }

                setOnCompletionListener {
                    if (!loopEnabled) {
                        Log.i(TAG, "Playback complete (non-looping)")
                        updateNotification(playing = false)
                    }
                }

                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Pipeline initialization failed", e)
            updateNotification(playing = false, error = true)
        }
    }

    // ── Resource Management ────────────────────────────────────────────────────

    private fun releaseResources(keepWakeLock: Boolean = false) {
        try {
            mediaPlayer?.apply {
                if (isPlaying) stop()
                release()
            }
            mediaPlayer = null

            frameRouter?.release()
            frameRouter = null

            surface?.release()
            surface = null

            surfaceTexture?.release()
            surfaceTexture = null

            isStarted = false
        } catch (e: Exception) {
            Log.w(TAG, "Error during resource release", e)
        }
    }

    // ── Wake Lock ──────────────────────────────────────────────────────────────

    private fun acquireWakeLock() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            WAKE_LOCK_TAG
        ).apply {
            acquire(3 * 60 * 60 * 1000L) // max 3 hours
        }
    }

    private fun releaseWakeLock() {
        if (wakeLock?.isHeld == true) {
            wakeLock?.release()
        }
        wakeLock = null
    }

    // ── Notifications ──────────────────────────────────────────────────────────

    private fun startForegroundWithNotification() {
        startForeground(
            VcamApp.NOTIFICATION_ID,
            buildNotification(playing = false)
        )
    }

    private fun updateNotification(playing: Boolean, error: Boolean = false) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(VcamApp.NOTIFICATION_ID, buildNotification(playing, error))
    }

    private fun buildNotification(playing: Boolean, error: Boolean = false): Notification {
        val contentText = when {
            error   -> "⚠ Playback error — tap to reopen"
            playing -> "🟢 Virtual camera active"
            else    -> "Starting virtual camera…"
        }

        val tapIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getBroadcast(
            this,
            0,
            Intent("com.vcamdroid.ACTION_STOP_SERVICE"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, VcamApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("VcamDroid")
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_vcam_notification)
            .setContentIntent(tapIntent)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                R.drawable.ic_stop,
                "Stop",
                stopIntent
            )
            .build()
    }
}

// ── Frame Router Interface ─────────────────────────────────────────────────────

/**
 * Modular injection interface.
 *
 * Implement this interface to swap out how decoded video frames are delivered
 * to the target sink (app camera preview, virtual display, system hook, etc.).
 */
interface FrameRouter {
    /** Called once before frames start arriving. */
    fun initialize()
    /** Called every time MediaPlayer outputs a new decoded frame. */
    fun onFrameAvailable(surfaceTexture: SurfaceTexture)
    /** Called when the service is stopping; release GPU/surface resources here. */
    fun release()
}

// ── Strategy 1: SurfaceTexture (in-app preview) ───────────────────────────────

/**
 * The default, permission-free router.
 *
 * Frames stay within the app process. An ExoPlayer-backed preview Surface can
 * subscribe to the same SurfaceTexture for in-app display. No system hooks,
 * no root required.
 */
class SurfaceTextureFrameRouter(
    private val width: Int,
    private val height: Int
) : FrameRouter {

    private val TAG = "SurfaceTextureRouter"

    override fun initialize() {
        Log.d(TAG, "SurfaceTexture router initialized ($width×$height)")
    }

    override fun onFrameAvailable(surfaceTexture: SurfaceTexture) {
        // In a real implementation this would update a shared texture that
        // the in-app CameraX/Camera2 preview reads from.
        // For the demo we simply log frame arrival.
        Log.v(TAG, "Frame available")
    }

    override fun release() {
        Log.d(TAG, "SurfaceTexture router released")
    }
}

// ── Strategy 2: VirtualDisplay (screen-share / MediaProjection path) ──────────

/**
 * Routes decoded frames into a [android.hardware.display.VirtualDisplay].
 *
 * Use case: Apps that hook screen capture (e.g. video calls that accept a
 * screen-share stream). Requires MEDIA_PROJECTION permission which must be
 * obtained from the user via MediaProjectionManager before creating this router.
 *
 * This class is a skeleton — wire [mediaProjection] from the activity result
 * callback of MediaProjectionManager.createScreenCaptureIntent().
 */
class VirtualDisplayFrameRouter(
    private val width: Int,
    private val height: Int,
    private val dpi: Int = 320,
    private val mediaProjection: android.media.projection.MediaProjection? = null
) : FrameRouter {

    private val TAG = "VirtualDisplayRouter"
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var outputSurface: Surface? = null

    override fun initialize() {
        if (mediaProjection == null) {
            Log.w(TAG, "No MediaProjection — VirtualDisplay router is a no-op")
            return
        }
        // Create a SurfaceTexture to receive frames and forward them to the virtual display
        val st = SurfaceTexture(0).apply { setDefaultBufferSize(width, height) }
        outputSurface = Surface(st)

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "VcamDroid-VirtualDisplay",
            width, height, dpi,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            outputSurface, null, null
        )
        Log.i(TAG, "VirtualDisplay created")
    }

    override fun onFrameAvailable(surfaceTexture: SurfaceTexture) {
        // Forward texture to virtualDisplay output surface via EGL blit (production impl)
    }

    override fun release() {
        virtualDisplay?.release()
        outputSurface?.release()
        Log.d(TAG, "VirtualDisplay router released")
    }
}

// ── Strategy 3 & 4 stubs — root/Xposed required ──────────────────────────────

/**
 * Camera2 Stub Router — skeleton for system-signed or root builds.
 *
 * A full implementation would register a virtual camera device via the
 * android.hardware.camera2 HAL (Camera HAL3 virtual device API, Android 14+)
 * or use /dev/video0 via V4L2 loopback on a rooted device.
 *
 * Reference: https://source.android.com/docs/core/camera/camera-vts
 */
class Camera2StubFrameRouter : FrameRouter {
    override fun initialize() = Unit   // Requires system permission
    override fun onFrameAvailable(surfaceTexture: SurfaceTexture) = Unit
    override fun release() = Unit
}

/**
 * Xposed / LSPosed Frame Router — skeleton for hook-based injection.
 *
 * A real implementation would:
 *   1. Hook Camera / Camera2 open() calls in the target app's process.
 *   2. Return a fake CaptureSession whose preview surface is backed by the
 *      video frames from this service.
 *
 * This requires LSPosed to be installed and this app to be declared as a module
 * in assets/xposed_init pointing to a class that extends IXposedHookLoadPackage.
 */
class XposedFrameRouter : FrameRouter {
    override fun initialize() = Unit   // Hooked at app load time
    override fun onFrameAvailable(surfaceTexture: SurfaceTexture) = Unit
    override fun release() = Unit
}
