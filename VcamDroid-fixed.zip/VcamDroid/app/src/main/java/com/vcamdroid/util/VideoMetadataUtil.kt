package com.vcamdroid.util

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns

object VideoMetadataUtil {

    /**
     * Queries the ContentResolver to build a [VideoInfo] from a URI.
     * Handles both MediaStore URIs and file:// / content:// from file pickers.
     */
    fun getVideoInfo(context: Context, uri: Uri): VideoInfo? {
        return try {
            val cr: ContentResolver = context.contentResolver
            var displayName = "Unknown"
            var fileSize = 0L
            var durationMs = 0L

            // Try OpenableColumns first (works for any content URI)
            cr.query(uri, null, null, null, null)?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (cursor.moveToFirst()) {
                    if (nameIdx >= 0) displayName = cursor.getString(nameIdx) ?: "Unknown"
                    if (sizeIdx >= 0) fileSize = cursor.getLong(sizeIdx)
                }
            }

            // Try MediaStore for duration (best effort)
            try {
                val projection = arrayOf(MediaStore.Video.Media.DURATION)
                cr.query(uri, projection, null, null, null)?.use { cursor ->
                    val durIdx = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                    if (cursor.moveToFirst() && durIdx >= 0) {
                        durationMs = cursor.getLong(durIdx)
                    }
                }
            } catch (_: Exception) {
                // Duration not always available; fall back to MediaMetadataRetriever
                durationMs = getDurationViaRetriever(context, uri)
            }

            if (durationMs == 0L) {
                durationMs = getDurationViaRetriever(context, uri)
            }

            VideoInfo(
                uri = uri,
                displayName = displayName,
                durationMs = durationMs,
                fileSizeBytes = fileSize,
                mimeType = cr.getType(uri) ?: "video/mp4"
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun getDurationViaRetriever(context: Context, uri: Uri): Long {
        return try {
            android.media.MediaMetadataRetriever().use { retriever ->
                retriever.setDataSource(context, uri)
                retriever.extractMetadata(
                    android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLongOrNull() ?: 0L
            }
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Checks whether a URI points to a playable video file.
     */
    fun isVideoUri(context: Context, uri: Uri): Boolean {
        val mimeType = context.contentResolver.getType(uri) ?: return false
        return mimeType.startsWith("video/")
    }
}
