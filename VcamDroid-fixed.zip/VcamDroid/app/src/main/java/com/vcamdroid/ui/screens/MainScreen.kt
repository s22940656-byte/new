package com.vcamdroid.ui.screens

import android.Manifest
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.*
import com.vcamdroid.ui.MainViewModel
import com.vcamdroid.ui.components.*
import com.vcamdroid.ui.theme.*
import com.vcamdroid.util.*

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MainScreen(
    viewModel: MainViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    // ── Permission Setup ────────────────────────────────────────────────────
    val videoPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        Manifest.permission.READ_MEDIA_VIDEO
    else
        Manifest.permission.READ_EXTERNAL_STORAGE

    val notifPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
        Manifest.permission.POST_NOTIFICATIONS
    else null

    val permissions = listOfNotNull(videoPermission, notifPermission)
    val permState = rememberMultiplePermissionsState(permissions) { results ->
        val allGranted = results.values.all { it }
        if (allGranted) viewModel.onPermissionsGranted()
        else viewModel.onPermissionsDenied()
    }

    LaunchedEffect(permState.allPermissionsGranted) {
        if (permState.allPermissionsGranted) viewModel.onPermissionsGranted()
    }

    // ── Video Picker ────────────────────────────────────────────────────────
    val videoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.onVideoSelected(it) }
    }

    // ── Root Layout ─────────────────────────────────────────────────────────
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Animated background grid
        GridBackground()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp)
                .padding(top = 56.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ── App Header ────────────────────────────────────────────────
            AppHeader()

            // ── Status Banner ─────────────────────────────────────────────
            StatusBanner(status = uiState.serviceStatus)

            // ── Error Snack ───────────────────────────────────────────────
            AnimatedVisibility(
                visible = uiState.errorMessage != null,
                enter = slideInVertically() + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                ErrorCard(
                    message = uiState.errorMessage ?: "",
                    onDismiss = viewModel::dismissError
                )
            }

            // ── Permissions Card ──────────────────────────────────────────
            if (!permState.allPermissionsGranted) {
                PermissionsCard(
                    onRequestPermissions = { permState.launchMultiplePermissionRequest() }
                )
            }

            // ── Video Preview Card ────────────────────────────────────────
            VideoPreviewCard(
                videoInfo = uiState.selectedVideo,
                isServiceActive = uiState.isServiceRunning,
                onPickVideo = {
                    if (permState.allPermissionsGranted) {
                        videoPicker.launch(arrayOf("video/mp4", "video/*"))
                    } else {
                        permState.launchMultiplePermissionRequest()
                    }
                },
                onClearVideo = viewModel::clearSelectedVideo
            )

            // ── Master Toggle ─────────────────────────────────────────────
            MasterToggleCard(
                uiState = uiState,
                onToggle = {
                    if (permState.allPermissionsGranted) {
                        viewModel.toggleService()
                    } else {
                        permState.launchMultiplePermissionRequest()
                    }
                }
            )

            // ── Settings Card ─────────────────────────────────────────────
            SettingsCard(
                isLoopEnabled = uiState.isLoopEnabled,
                isMirrorEnabled = uiState.isMirrorEnabled,
                isServiceRunning = uiState.isServiceRunning,
                onLoopChanged = viewModel::setLoopEnabled,
                onMirrorChanged = viewModel::setMirrorEnabled
            )

            // ── Injection Method Card ─────────────────────────────────────
            InjectionMethodCard(
                selected = uiState.injectionMethod,
                onSelect = viewModel::setInjectionMethod,
                isServiceRunning = uiState.isServiceRunning
            )

            // ── Info Card ─────────────────────────────────────────────────
            InfoCard()

            Spacer(Modifier.height(16.dp))
        }
    }
}
