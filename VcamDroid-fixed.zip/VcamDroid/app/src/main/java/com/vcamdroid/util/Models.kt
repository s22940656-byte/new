package com.vcamdroid.util

import android.net.Uri

// ── Service State ────────────────────────────────────────────────────────────

enum class ServiceStatus {
    IDLE,       // No video selected, service not running
    READY,      // Video selected, service not running
    STARTING,   // Service spinning up
    ACTIVE,     // Service running, video streaming
    STOPPING,   // Service shutting down
    ERROR       // Something went wrong
}

data class VideoInfo(
    val uri: Uri,
    val displayName: String,
    val durationMs: Long,
    val fileSizeBytes: Long,
    val mimeType: String = "video/mp4"
) {
    val durationFormatted: String get() {
        val totalSecs = durationMs / 1000
        val hours = totalSecs / 3600
        val mins = (totalSecs % 3600) / 60
        val secs = totalSecs % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, mins, secs)
        } else {
            String.format("%02d:%02d", mins, secs)
        }
    }

    val fileSizeFormatted: String get() {
        return when {
            fileSizeBytes < 1024 -> "$fileSizeBytes B"
            fileSizeBytes < 1024 * 1024 -> "${fileSizeBytes / 1024} KB"
            fileSizeBytes < 1024 * 1024 * 1024 -> "%.1f MB".format(fileSizeBytes / (1024.0 * 1024.0))
            else -> "%.2f GB".format(fileSizeBytes / (1024.0 * 1024.0 * 1024.0))
        }
    }
}

// ── UI State ─────────────────────────────────────────────────────────────────

data class MainUiState(
    val serviceStatus: ServiceStatus = ServiceStatus.IDLE,
    val selectedVideo: VideoInfo? = null,
    val isLoopEnabled: Boolean = true,
    val isMirrorEnabled: Boolean = false,
    val playbackPositionMs: Long = 0L,
    val errorMessage: String? = null,
    val permissionsGranted: Boolean = false,
    val showPermissionRationale: Boolean = false,
    val injectionMethod: InjectionMethod = InjectionMethod.SURFACE_TEXTURE
) {
    val canStartService: Boolean get() =
        selectedVideo != null && serviceStatus == ServiceStatus.READY
    val isServiceRunning: Boolean get() =
        serviceStatus == ServiceStatus.ACTIVE || serviceStatus == ServiceStatus.STARTING
}

enum class InjectionMethod(val label: String, val description: String) {
    SURFACE_TEXTURE(
        "SurfaceTexture",
        "Routes video frames through a custom SurfaceTexture. Works within-app."
    ),
    VIRTUAL_DISPLAY(
        "Virtual Display",
        "Creates a virtual display and mirrors video. Best for screen sharing hooks."
    ),
    CAMERA2_STUB(
        "Camera2 Stub",
        "Provides a Camera2 API shim. Requires root or system-signed builds."
    ),
    XPOSED_MODULE(
        "Xposed / LSPosed",
        "Full system-wide hook via Xposed framework. Requires LSPosed installed."
    )
}

// ── Service Messages ──────────────────────────────────────────────────────────

sealed class ServiceCommand {
    data class Start(val videoUri: Uri, val loop: Boolean, val mirror: Boolean) : ServiceCommand()
    object Stop : ServiceCommand()
    data class UpdateSettings(val loop: Boolean, val mirror: Boolean) : ServiceCommand()
}

// ── Constants ────────────────────────────────────────────────────────────────

object Constants {
    const val SERVICE_ACTION_START  = "com.vcamdroid.action.START"
    const val SERVICE_ACTION_STOP   = "com.vcamdroid.action.STOP"
    const val SERVICE_ACTION_UPDATE = "com.vcamdroid.action.UPDATE"
    const val EXTRA_VIDEO_URI       = "extra_video_uri"
    const val EXTRA_LOOP_ENABLED    = "extra_loop_enabled"
    const val EXTRA_MIRROR_ENABLED  = "extra_mirror_enabled"
    const val PREF_LAST_VIDEO_URI   = "pref_last_video_uri"
    const val PREF_LOOP_ENABLED     = "pref_loop_enabled"
    const val PREF_MIRROR_ENABLED   = "pref_mirror_enabled"
    const val PREF_INJECTION_METHOD = "pref_injection_method"
}
