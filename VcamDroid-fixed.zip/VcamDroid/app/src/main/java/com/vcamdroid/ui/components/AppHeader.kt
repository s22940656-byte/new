package com.vcamdroid.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vcamdroid.ui.theme.*

// ── App Header ────────────────────────────────────────────────────────────────

@Composable
fun AppHeader(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "headerPulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1800, easing = FastOutSlowInEasing),
            RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Icon with glow
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Rounded.Videocam,
                contentDescription = null,
                tint = NeonCyan.copy(alpha = glowAlpha * 0.3f),
                modifier = Modifier.size(44.dp)
            )
            Icon(
                imageVector = Icons.Rounded.Videocam,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(32.dp)
            )
        }

        Column {
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 26.sp)) {
                        append("Vcam")
                    }
                    withStyle(SpanStyle(color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 26.sp)) {
                        append("Droid")
                    }
                }
            )
            Text(
                text = "Virtual Camera Engine",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }

        Spacer(Modifier.weight(1f))

        // Version badge
        Surface(
            color = ElevatedNavy,
            shape = MaterialTheme.shapes.small,
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderBlue)
        ) {
            Text(
                text = "v1.0",
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
        }
    }
}

// ── Animated Grid Background ──────────────────────────────────────────────────

@Composable
fun GridBackground(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "grid")
    val scanOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(4000, easing = LinearEasing)),
        label = "scan"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        drawGrid(this, Color(0xFF0D1520), Color(0xFF1E3050))
        drawScanLine(this, scanOffset, NeonCyan.copy(alpha = 0.07f))
    }
}

private fun drawGrid(scope: DrawScope, bg: Color, lineColor: Color) {
    val step = 40f
    var x = 0f
    while (x <= scope.size.width) {
        scope.drawLine(lineColor, Offset(x, 0f), Offset(x, scope.size.height), strokeWidth = 0.5f)
        x += step
    }
    var y = 0f
    while (y <= scope.size.height) {
        scope.drawLine(lineColor, Offset(0f, y), Offset(scope.size.width, y), strokeWidth = 0.5f)
        y += step
    }
}

private fun drawScanLine(scope: DrawScope, fraction: Float, color: Color) {
    val y = scope.size.height * fraction
    scope.drawLine(color, Offset(0f, y), Offset(scope.size.width, y), strokeWidth = 2f)
}
