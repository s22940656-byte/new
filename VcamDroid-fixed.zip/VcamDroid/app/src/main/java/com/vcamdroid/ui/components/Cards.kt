package com.vcamdroid.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vcamdroid.ui.theme.*
import com.vcamdroid.util.InjectionMethod

// ── Shared Card Shell ─────────────────────────────────────────────────────────

@Composable
fun VcamCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceNavy)
            .border(1.dp, BorderBlue, RoundedCornerShape(14.dp))
            .padding(18.dp),
        content = content
    )
}

// ── Settings Card ─────────────────────────────────────────────────────────────

@Composable
fun SettingsCard(
    isLoopEnabled: Boolean,
    isMirrorEnabled: Boolean,
    isServiceRunning: Boolean,
    onLoopChanged: (Boolean) -> Unit,
    onMirrorChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    VcamCard(modifier = modifier) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Tune, null, Modifier.size(18.dp), tint = NeonCyan)
            Spacer(Modifier.width(8.dp))
            Text("PLAYBACK SETTINGS", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
        }

        Spacer(Modifier.height(14.dp))

        SettingToggleRow(
            icon = Icons.Rounded.Loop,
            label = "Loop video",
            description = "Restart when playback ends",
            checked = isLoopEnabled,
            onCheckedChange = onLoopChanged,
            enabled = true // loop can be toggled live
        )

        HorizontalDivider(color = BorderBlue, modifier = Modifier.padding(vertical = 10.dp))

        SettingToggleRow(
            icon = Icons.Rounded.Flip,
            label = "Mirror output",
            description = "Horizontally flip the video frame",
            checked = isMirrorEnabled,
            onCheckedChange = onMirrorChanged,
            enabled = !isServiceRunning // require restart
        )

        if (isMirrorEnabled && isServiceRunning) {
            Spacer(Modifier.height(6.dp))
            Text(
                "↺ Restart the service to apply mirror changes",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: ImageVector,
    label: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    enabled: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = TextSecondary)
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = if (enabled) TextPrimary else TextTertiary,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = TextTertiary
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DeepNavy,
                checkedTrackColor = NeonCyan,
                uncheckedTrackColor = ElevatedNavy,
                uncheckedThumbColor = TextTertiary
            )
        )
    }
}

// ── Injection Method Card ─────────────────────────────────────────────────────

@Composable
fun InjectionMethodCard(
    selected: InjectionMethod,
    onSelect: (InjectionMethod) -> Unit,
    isServiceRunning: Boolean,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    VcamCard(modifier = modifier) {
        // Header / toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = !expanded },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.DeviceHub, null, Modifier.size(18.dp), tint = NeonCyan)
            Spacer(Modifier.width(8.dp))
            Text("INJECTION METHOD", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
            Spacer(Modifier.weight(1f))
            Icon(
                if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                null,
                Modifier.size(18.dp),
                tint = TextSecondary
            )
        }

        Spacer(Modifier.height(10.dp))

        // Current selection summary
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Surface(
                color = NeonCyan.copy(0.12f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = selected.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonCyan,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
            Text(
                text = selected.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                modifier = Modifier.weight(1f)
            )
        }

        // Expandable list
        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Column(modifier = Modifier.padding(top = 14.dp)) {
                HorizontalDivider(color = BorderBlue, modifier = Modifier.padding(bottom = 12.dp))

                InjectionMethod.entries.forEach { method ->
                    val isSelected = method == selected
                    val requiresRoot = method == InjectionMethod.CAMERA2_STUB ||
                                       method == InjectionMethod.XPOSED_MODULE

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) NeonCyan.copy(0.07f) else Color.Transparent)
                            .border(
                                1.dp,
                                if (isSelected) NeonCyan.copy(0.4f) else Color.Transparent,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable(enabled = !isServiceRunning) {
                                onSelect(method)
                                expanded = false
                            }
                            .padding(12.dp),
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = NeonCyan,
                                unselectedColor = TextTertiary
                            )
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = method.label,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isSelected) NeonCyan else TextPrimary,
                                    fontWeight = FontWeight.Medium
                                )
                                if (requiresRoot) {
                                    Surface(
                                        color = ErrorRed.copy(0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            "ROOT",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ErrorRed,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                            Text(
                                text = method.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    if (method != InjectionMethod.entries.last()) {
                        Spacer(Modifier.height(6.dp))
                    }
                }

                if (isServiceRunning) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "⏹ Stop the service to change injection method",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

// ── Permissions Card ──────────────────────────────────────────────────────────

@Composable
fun PermissionsCard(
    onRequestPermissions: () -> Unit,
    modifier: Modifier = Modifier
) {
    VcamCard(modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(Icons.Rounded.Lock, null, Modifier.size(22.dp), tint = Color(0xFFFFAA00))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "Permissions Required",
                    style = MaterialTheme.typography.headlineSmall,
                    color = TextPrimary
                )
                Text(
                    "VcamDroid needs access to your video files (READ_MEDIA_VIDEO) and notifications to run the background service.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                Spacer(Modifier.height(4.dp))
                Button(
                    onClick = onRequestPermissions,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFFAA00),
                        contentColor = DeepNavy
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Grant Permissions", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

// ── Error Card ────────────────────────────────────────────────────────────────

@Composable
fun ErrorCard(
    message: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(ErrorRed.copy(0.1f))
            .border(1.dp, ErrorRed.copy(0.4f), RoundedCornerShape(10.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(Icons.Rounded.ErrorOutline, null, Modifier.size(20.dp), tint = ErrorRed)
        Text(
            text = message,
            style = MaterialTheme.typography.bodySmall,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
            Icon(Icons.Rounded.Close, null, tint = TextSecondary)
        }
    }
}

// ── Info Card ─────────────────────────────────────────────────────────────────

@Composable
fun InfoCard(modifier: Modifier = Modifier) {
    VcamCard(modifier = modifier) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Rounded.InfoOutline, null, Modifier.size(18.dp), tint = NeonCyan)
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    "How It Works",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
                InfoPoint("SurfaceTexture mode routes video into an in-app preview surface (no root needed).")
                InfoPoint("Virtual Display mode mirrors frames into a system display (useful for screen-share apps).")
                InfoPoint("Camera2 Stub / Xposed modes require a rooted device or LSPosed framework for system-wide injection.")
                InfoPoint("The foreground service keeps playback alive when the app is backgrounded.")
            }
        }
    }
}

@Composable
private fun InfoPoint(text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("•", style = MaterialTheme.typography.bodySmall, color = NeonCyan)
        Text(text, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
    }
}
